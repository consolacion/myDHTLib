# RemoteSwitch
Remote control transmitters for many popular switches

The RemoteSwitch class contains a substantial number of 433 Mhz encoders. It is based on Randy Simons great work.

The RemoteReceiver class contains original decoders, but these are obsolete. I will replace them soon with a better
and more modular design, containing also several Weather Station decoders.

License: "Free BSD license".
